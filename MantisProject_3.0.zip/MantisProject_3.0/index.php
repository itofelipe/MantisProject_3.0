<?php get_header(); ?>

	<?php include('template-parts/home.php');?>

	<?php include('template-parts/services.php');?>

	<?php include('template-parts/break_1.php');?>

	<?php include('template-parts/portfolio.php');?>

	<?php include('template-parts/clients.php');?>

	<?php include('template-parts/break_2.php');?>

	<?php include('template-parts/codes.php');?>
	
<?php get_footer(); ?>