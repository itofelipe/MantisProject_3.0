    <section id="home" class="home">    
        <img data-aos="zoom-in" data-aos-delay="1200" data-aos-easing="ease-in-out" data-aos-duration="1500" src="<?php echo get_template_directory_uri(); ?>/assets/images/logo.png" />
    </section>