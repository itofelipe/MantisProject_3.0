    <section id="break_1" class="break_1">
        <h4  data-aos="fade" data-aos-delay="300" data-aos-easing="ease-in-out" data-aos-duration="800">Designing <span>everything</span></h4>
    </section>