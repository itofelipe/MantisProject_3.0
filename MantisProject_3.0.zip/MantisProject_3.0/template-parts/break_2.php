    <section id="break_2" class="break_2">  
        <h4 data-aos="fade" data-aos-delay="300" data-aos-easing="ease-in-out" data-aos-duration="800">Developing <span>and </span>evolving</h4>
    </section>